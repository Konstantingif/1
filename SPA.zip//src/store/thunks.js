import {
  fetchProductsRequest,
  fetchProductsSuccess,
  fetchProductsFailure,
  submitFormRequest,
  submitFormSuccess,
  submitFormFailure,
} from "./actions";
import { fetchProducts, submitFormData } from "../utils/api";

export const getProducts = () => {
  return async (dispatch) => {
    dispatch(fetchProductsRequest());
    console.log("getProducts: fetchProductsRequest dispatched");
    try {
      const products = await fetchProducts();
      console.log("getProducts: fetchProducts data:", products);
      dispatch(fetchProductsSuccess(products));
      console.log("getProducts: fetchProductsSuccess dispatched");
    } catch (error) {
      console.log("getProducts: fetchProductsFailure Error:", error.message);
      dispatch(fetchProductsFailure(error.message));
    }
  };
};
