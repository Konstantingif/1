import {
  FETCH_PRODUCTS_REQUEST,
  FETCH_PRODUCTS_SUCCESS,
  FETCH_PRODUCTS_FAILURE,
  SELECT_PRODUCT,
  SUBMIT_FORM_REQUEST,
  SUBMIT_FORM_SUCCESS,
  SUBMIT_FORM_FAILURE,
} from "./types";

export const fetchProductsRequest = () => ({
  type: FETCH_PRODUCTS_REQUEST,
});

export const fetchProductsSuccess = (products) => ({
  type: FETCH_PRODUCTS_SUCCESS,
  payload: products,
});

export const fetchProductsFailure = (error) => ({
  type: FETCH_PRODUCTS_FAILURE,
  payload: error,
});

export const selectProduct = (productId) => ({
  type: SELECT_PRODUCT,
  payload: productId,
});

export const submitFormRequest = () => ({
  type: SUBMIT_FORM_REQUEST,
});

export const submitFormSuccess = () => ({
  type: SUBMIT_FORM_SUCCESS,
});

export const submitFormFailure = (error) => ({
  type: SUBMIT_FORM_FAILURE,
  payload: error,
});
