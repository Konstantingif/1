import {
  FETCH_PRODUCTS_REQUEST,
  FETCH_PRODUCTS_SUCCESS,
  FETCH_PRODUCTS_FAILURE,
  SELECT_PRODUCT,
  SUBMIT_FORM_REQUEST,
  SUBMIT_FORM_SUCCESS,
  SUBMIT_FORM_FAILURE,
} from "./types";

const initialState = {
  products: [],
  selectedProductId: null,
  loading: false,
  error: null,
  formSubmitting: false,
  formError: null,
  formSubmitted: false,
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_PRODUCTS_REQUEST:
      return { ...state, loading: true, error: null };
    case FETCH_PRODUCTS_SUCCESS:
      console.log("reducer: FETCH_PRODUCTS_SUCCESS payload:", action.payload);
      return { ...state, loading: false, products: action.payload };
    case FETCH_PRODUCTS_FAILURE:
      return { ...state, loading: false, error: action.payload };
    case SELECT_PRODUCT:
      return { ...state, selectedProductId: action.payload };
    case SUBMIT_FORM_REQUEST:
      return {
        ...state,
        formSubmitting: true,
        formError: null,
        formSubmitted: false,
      };
    case SUBMIT_FORM_SUCCESS:
      return { ...state, formSubmitting: false, formSubmitted: true };
    case SUBMIT_FORM_FAILURE:
      return { ...state, formSubmitting: false, formError: action.payload };
    default:
      return state;
  }
};

export default reducer;
