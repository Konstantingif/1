import React from "react";
import ProductCard from "./ProductCard";
import "../styles/components.css";

const ProductList = React.memo(({ products, onSelect }) => {
  return (
    <div className="container">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} onSelect={onSelect} />
      ))}
    </div>
  );
});

export default ProductList;
