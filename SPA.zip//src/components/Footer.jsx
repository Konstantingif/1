import React from "react";
import "../styles/layout.css";

const Footer = () => {
  return (
    <footer className="footer">
      <p>&copy; {new Date().getFullYear()} My SPA App</p>
    </footer>
  );
};

export default React.memo(Footer);
