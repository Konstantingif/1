import React from "react";
import "../styles/components.css";

const Loading = () => {
  return (
    <div className="loading-overlay">
      <div>Loading...</div>
    </div>
  );
};

export default Loading;
