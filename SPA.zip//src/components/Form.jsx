import React, { useState, useCallback } from "react";
import { useDispatch, useSelector } from "react-redux";
import { submitForm } from "../store/thunks";
import "../styles/components.css";

const Form = React.memo(() => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const dispatch = useDispatch();
  const { formSubmitting, formError, formSubmitted } = useSelector(
    (state) => state
  );

  const handleChange = useCallback((e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({ ...prevState, [name]: value }));
  }, []);

  const handleSubmit = useCallback(
    (e) => {
      e.preventDefault();
      dispatch(submitForm(formData));
    },
    [dispatch, formData]
  );

  return (
    <div className="form-container">
      {formSubmitted ? (
        <p>Form submitted successfully</p>
      ) : (
        <form onSubmit={handleSubmit}>
          <label>
            Name:
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </label>
          <label>
            Email:
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </label>
          <label>
            Message:
            <textarea
              name="message"
              value={formData.message}
              onChange={handleChange}
              required
            />
          </label>
          {formError && <p style={{ color: "red" }}>{formError}</p>}
          <button type="submit" disabled={formSubmitting} className="button">
            {formSubmitting ? "Submitting..." : "Submit"}
          </button>
        </form>
      )}
    </div>
  );
});

export default Form;
