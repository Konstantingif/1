import React from "react";
import "../styles/components.css";

const ProductCard = React.memo(({ product, onSelect }) => {
  return (
    <div className="product-card">
      <img src={product.image} alt={product.title} />
      <h3>{product.title}</h3>
      <p>{product.price}</p>
      <button onClick={() => onSelect(product.id)} className="button">
        Select
      </button>
    </div>
  );
});

export default ProductCard;
