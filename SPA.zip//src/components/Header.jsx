import React from "react";
import { Link } from "react-router-dom";

const logo = process.env.PUBLIC_URL + "/assets/images/logo.png";
const menuIcon = process.env.PUBLIC_URL + "/assets/icons/menu.svg";
import "../styles/layout.css";

const Header = () => {
  return (
    <header className="header">
      <img src={logo} alt="logo" />
      <nav>
        <ul className="nav-menu">
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/products">Products</Link>
          </li>
          <li>
            <Link to="/contact">Contact</Link>
          </li>
        </ul>
      </nav>
      <img src={menuIcon} alt="menu" className="menu-icon" />
    </header>
  );
};

export default React.memo(Header);
