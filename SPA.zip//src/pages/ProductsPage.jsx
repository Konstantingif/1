import React, { useEffect, useCallback } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getProducts } from "../store/thunks";
import { selectProduct } from "../store/actions";
import ProductList from "../components/ProductList";
import Loading from "../components/Loading";

const ProductsPage = () => {
  const dispatch = useDispatch();
  const { products, loading } = useSelector((state) => {
    console.log("ProductsPage: State from useSelector:", state);
    return state;
  });

  useEffect(() => {
    console.log("ProductsPage: getProducts dispatch start");
    dispatch(getProducts());
  }, [dispatch]);

  const handleSelect = useCallback(
    (productId) => {
      dispatch(selectProduct(productId));
    },
    [dispatch]
  );

  if (loading) {
    return <Loading />;
  }
  return (
    <div>
      <h2>Products</h2>
      <ProductList products={products} onSelect={handleSelect} />
    </div>
  );
};

export default React.memo(ProductsPage);
