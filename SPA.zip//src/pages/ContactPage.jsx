import React from "react";
import Form from "../components/Form";

const ContactPage = () => {
  return (
    <div className="container">
      <h2>Contact Us</h2>
      <Form />
    </div>
  );
};

export default React.memo(ContactPage);
