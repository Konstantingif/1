import React from "react";

const HomePage = () => {
  return (
    <div className="container">
      <h2>Welcome to Home Page</h2>
      <p>This is the home page of our SPA application.</p>
    </div>
  );
};

export default React.memo(HomePage);
