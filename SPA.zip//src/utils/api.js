import axios from "axios";

const API_BASE_URL = "https://fakestoreapi.com"; // Замените на ваш API URL

export const fetchProducts = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/products`);
    return response.data;
  } catch (error) {
    throw new Error("Failed to fetch products");
  }
};
export const submitFormData = async (formData) => {
  try {
    await axios.post(`${API_BASE_URL}/submit-form`, formData);
    return true;
  } catch (error) {
    throw new Error("Failed to submit form");
  }
};
